package main;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.Scanner;

import exception.GymException;
import model.BillingCycle;
import service.GymService;

public class Main {

    private static final Scanner scanner = new Scanner(System.in);
    private static final GymService gym = new GymService();

    public static void main(String[] args) {
        boolean running = true;
        System.out.println("===== GYM MEMBERSHIP & BILLING SYSTEM =====");
        while (running) {
            displayMenu();
            int choice;
            try {
                choice = readInt("Enter your choice: ");
            } catch (GymException ex) {
                System.out.println("Error: " + ex.getMessage());
                continue;
            }
            try {
                switch (choice) {
                    case 1:
                        addMember();
                        break;
                    case 2:
                        addPlan();
                        break;
                    case 3:
                        startOrRenew();
                        break;
                    case 4:
                        recordAttendance();
                        break;
                    case 5:
                        gym.generateInvoice(readPositiveInt("Enter member ID: "));
                        break;
                    case 6:
                        recordPayment();
                        break;
                    case 7:
                        gym.displayMembers();
                        break;
                    case 8:
                        running = false;
                        System.out.println("Thank you for using the Gym Membership & Billing System.");
                        break;
                    default:
                        System.out.println("Invalid choice. Please select 1 to 8.");
                }
            } catch (GymException ex) {
                System.out.println("Error: " + ex.getMessage());
            }
        }
        scanner.close();
    }

    private static void displayMenu() {
        System.out.println("\n1. Add Member");
        System.out.println("2. Add Plan");
        System.out.println("3. Start or Renew Subscription");
        System.out.println("4. Record Attendance");
        System.out.println("5. Generate Invoice");
        System.out.println("6. Record Payment");
        System.out.println("7. Display Members");
        System.out.println("8. Exit");
    }

    private static void addMember() {
        int id = readPositiveInt("Enter member ID: ");
        String name = readText("Enter member name: ");
        String phone = readText("Enter phone number (10 digits): ");
        if (!phone.matches("\\d{10}")) {
            throw new GymException("Phone number must be exactly 10 digits.");
        }
        System.out.println("Available trainers:");
        gym.displayTrainers();
        int trainerId = readPositiveInt("Enter trainer ID: ");
        gym.addMember(id, name, phone, trainerId);
    }

    private static void addPlan() {
        int id = readPositiveInt("Enter plan ID: ");
        String name = readText("Enter plan name: ");
        String type = readText("Enter plan type (standard/premium): ");
        if (!type.equalsIgnoreCase("standard") && !type.equalsIgnoreCase("premium")) {
            throw new GymException("Plan type must be standard or premium.");
        }
        BillingCycle cycle = readCycle();
        double price = readPositiveDouble("Enter plan price (Rs.): ");
        int grace = readNonNegativeInt("Enter grace days for late renewal: ");
        double penalty = readPositiveDouble("Enter penalty per late day (Rs.): ");
        gym.addPlan(id, name, type.equalsIgnoreCase("premium"), cycle, price, grace, penalty);
    }

    private static void startOrRenew() {
        int memberId = readPositiveInt("Enter member ID: ");
        System.out.println("Available plans:");
        gym.displayPlans();
        int planId = readPositiveInt("Enter plan ID: ");
        LocalDate date = readOptionalDate("Enter start date (yyyy-MM-dd, blank = today): ");
        gym.startOrRenew(memberId, planId, date);
    }

    private static void recordAttendance() {
        int memberId = readPositiveInt("Enter member ID: ");
        LocalDate date = readOptionalDate("Enter visit date (yyyy-MM-dd, blank = today): ");
        gym.recordAttendance(memberId, date);
    }

    private static void recordPayment() {
        int invoiceId = readPositiveInt("Enter invoice ID: ");
        double amount = readPositiveDouble("Enter amount paid (Rs.): ");
        String method = readText("Enter payment method (Cash/Card/UPI): ");
        gym.recordPayment(invoiceId, amount, method);
    }

    private static BillingCycle readCycle() {
        System.out.println("Billing cycle: 1. Monthly  2. Quarterly  3. Yearly");
        int c = readInt("Choose cycle: ");
        switch (c) {
            case 1:
                return BillingCycle.MONTHLY;
            case 2:
                return BillingCycle.QUARTERLY;
            case 3:
                return BillingCycle.YEARLY;
            default:
                throw new GymException("Billing cycle must be 1, 2 or 3.");
        }
    }

    private static int readInt(String prompt) {
        System.out.print(prompt);
        String input = scanner.nextLine().trim();
        try {
            return Integer.parseInt(input);
        } catch (NumberFormatException ex) {
            throw new GymException("Please enter a valid whole number.");
        }
    }

    private static int readPositiveInt(String prompt) {
        int value = readInt(prompt);
        if (value <= 0) {
            throw new GymException("Value must be greater than zero.");
        }
        return value;
    }

    private static int readNonNegativeInt(String prompt) {
        int value = readInt(prompt);
        if (value < 0) {
            throw new GymException("Value cannot be negative.");
        }
        return value;
    }

    private static double readPositiveDouble(String prompt) {
        System.out.print(prompt);
        String input = scanner.nextLine().trim();
        double value;
        try {
            value = Double.parseDouble(input);
        } catch (NumberFormatException ex) {
            throw new GymException("Please enter a valid amount.");
        }
        if (value <= 0) {
            throw new GymException("Value must be greater than zero.");
        }
        return value;
    }

    private static String readText(String prompt) {
        System.out.print(prompt);
        String value = scanner.nextLine().trim();
        if (value.isEmpty()) {
            throw new GymException("This field cannot be empty.");
        }
        return value;
    }

    private static LocalDate readOptionalDate(String prompt) {
        System.out.print(prompt);
        String value = scanner.nextLine().trim();
        if (value.isEmpty()) {
            return GymService.today();
        }
        try {
            return LocalDate.parse(value);
        } catch (DateTimeParseException ex) {
            throw new GymException("Date must be in yyyy-MM-dd format.");
        }
    }
}
