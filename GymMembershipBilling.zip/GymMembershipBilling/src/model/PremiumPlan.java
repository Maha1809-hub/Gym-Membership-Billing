package model;

public class PremiumPlan extends Plan {

    private static final double PENALTY_CAP = 300.0;

    public PremiumPlan(int planId, String name, BillingCycle cycle, double price, int graceDays, double penaltyPerDay) {
        super(planId, name, cycle, price, graceDays, penaltyPerDay);
    }

    @Override
    public String getType() {
        return "Premium";
    }

    @Override
    public double calculatePenalty(long daysLate) {
        return Math.min(super.calculatePenalty(daysLate), PENALTY_CAP);
    }

    @Override
    public String policyText() {
        return super.policyText() + ", capped at Rs. " + PENALTY_CAP;
    }
}
