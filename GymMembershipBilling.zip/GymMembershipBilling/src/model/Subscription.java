package model;

import java.time.LocalDate;

public class Subscription {

    private final int subscriptionId;
    private final Member member;
    private final Plan plan;
    private final LocalDate startDate;
    private final LocalDate endDate;
    private final double penalty;
    private boolean invoiced;

    public Subscription(int subscriptionId, Member member, Plan plan,
                        LocalDate startDate, double penalty) {
        this.subscriptionId = subscriptionId;
        this.member = member;
        this.plan = plan;
        this.startDate = startDate;
        this.endDate = startDate.plusDays(plan.getCycle().getDays());
        this.penalty = penalty;
    }

    public int getSubscriptionId() {
        return subscriptionId;
    }

    public Member getMember() {
        return member;
    }

    public Plan getPlan() {
        return plan;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public double getPenalty() {
        return penalty;
    }

    public boolean isInvoiced() {
        return invoiced;
    }

    public void setInvoiced(boolean invoiced) {
        this.invoiced = invoiced;
    }

    public boolean isActiveOn(LocalDate date) {
        return !date.isBefore(startDate) && !date.isAfter(endDate);
    }

    public String getStatus(LocalDate today) {
        return isActiveOn(today) ? "ACTIVE" : "EXPIRED";
    }

    public void displayStatus(LocalDate today) {
        System.out.println("Member: " + member.getName() + " (ID: " + member.getId() + ")");
        System.out.println("Plan: " + plan.getName() + " (" + plan.getCycle() + ")");
        System.out.println("Status: " + getStatus(today));
        System.out.println("Valid from: " + startDate + "\tto\t" + endDate);
    }
}
