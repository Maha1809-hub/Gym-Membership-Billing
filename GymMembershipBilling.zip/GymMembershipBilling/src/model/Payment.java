package model;

import java.time.LocalDate;

public class Payment {

    private final int paymentId;
    private final Invoice invoice;
    private final double amount;
    private final String method;
    private final LocalDate date;

    public Payment(int paymentId, Invoice invoice, double amount, String method, LocalDate date) {
        this.paymentId = paymentId;
        this.invoice = invoice;
        this.amount = amount;
        this.method = method;
        this.date = date;
    }

    public void displayReceipt() {
        System.out.println("\n========== PAYMENT RECEIPT ==========");
        System.out.println("Payment ID : " + paymentId);
        System.out.println("Invoice ID : " + invoice.getInvoiceId());
        System.out.println("Member     : " + invoice.getSubscription().getMember().getName());
        System.out.printf("Amount     : Rs. %.2f%n", amount);
        System.out.println("Method     : " + method);
        System.out.println("Date       : " + date);
        System.out.println("Invoice    : " + (invoice.isPaid() ? "PAID" : "UNPAID"));
        System.out.println("=====================================");
    }
}
