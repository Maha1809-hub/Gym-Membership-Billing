package model;

public class Plan {

    private final int planId;
    private final String name;
    private final BillingCycle cycle;
    private final double price;
    private final int graceDays;
    private final double penaltyPerDay;

    public Plan(int planId, String name, BillingCycle cycle, double price, int graceDays, double penaltyPerDay) {
        this.planId = planId;
        this.name = name;
        this.cycle = cycle;
        this.price = price;
        this.graceDays = graceDays;
        this.penaltyPerDay = penaltyPerDay;
    }

    public int getPlanId() {
        return planId;
    }

    public String getName() {
        return name;
    }

    public BillingCycle getCycle() {
        return cycle;
    }

    public double getPrice() {
        return price;
    }

    public int getGraceDays() {
        return graceDays;
    }

    public double getPenaltyPerDay() {
        return penaltyPerDay;
    }

    public String getType() {
        return "Standard";
    }

    public double calculatePenalty(long daysLate) {
        long chargeable = Math.max(0, daysLate - graceDays);
        return chargeable * penaltyPerDay;
    }

    public String policyText() {
        return "Rs. " + penaltyPerDay + "/day after " + graceDays + " grace days";
    }

    @Override
    public String toString() {
        return String.format("Plan %d: %s [%s, %s] Price: Rs. %.2f | Penalty: %s",
                planId, name, getType(), cycle, price, policyText());
    }
}
