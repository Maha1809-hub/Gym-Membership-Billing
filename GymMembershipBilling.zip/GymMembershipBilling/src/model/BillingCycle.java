package model;

public enum BillingCycle {

    MONTHLY(30), QUARTERLY(90), YEARLY(365);

    private final int days;

    BillingCycle(int days) {
        this.days = days;
    }

    public int getDays() {
        return days;
    }
}
