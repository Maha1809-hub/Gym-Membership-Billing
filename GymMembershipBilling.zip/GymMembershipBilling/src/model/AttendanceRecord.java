package model;

import java.time.LocalDate;

public class AttendanceRecord {

    private final Member member;
    private final LocalDate date;

    public AttendanceRecord(Member member, LocalDate date) {
        this.member = member;
        this.date = date;
    }

    public Member getMember() {
        return member;
    }

    public LocalDate getDate() {
        return date;
    }
}
