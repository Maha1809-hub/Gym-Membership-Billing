package model;

public class Trainer extends Person {

    private final String speciality;

    public Trainer(int id, String name, String speciality) {
        super(id, name);
        this.speciality = speciality;
    }

    public String getSpeciality() {
        return speciality;
    }

    @Override
    public String getRole() {
        return "Trainer";
    }

    @Override
    public String toString() {
        return "Trainer " + getId() + ": " + getName() + " (" + speciality + ")";
    }
}
