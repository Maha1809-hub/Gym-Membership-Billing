package model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Member extends Person {

    private final String phone;
    private final Trainer trainer;
    private Subscription currentSubscription;
    private final List<AttendanceRecord> attendance = new ArrayList<>();

    public Member(int id, String name, String phone, Trainer trainer) {
        super(id, name);
        this.phone = phone;
        this.trainer = trainer;
    }

    public String getPhone() {
        return phone;
    }

    public Trainer getTrainer() {
        return trainer;
    }

    public Subscription getCurrentSubscription() {
        return currentSubscription;
    }

    public void setCurrentSubscription(Subscription subscription) {
        this.currentSubscription = subscription;
    }

    public List<AttendanceRecord> getAttendance() {
        return attendance;
    }

    public void addAttendance(AttendanceRecord record) {
        attendance.add(record);
    }

    @Override
    public String getRole() {
        return "Member";
    }

    public void displayMember(LocalDate today) {
        System.out.println("Member ID: " + getId() + " | Name: " + getName()
                + " | Phone: " + phone + " | Trainer: " + trainer.getName());
        if (currentSubscription == null) {
            System.out.println("\tSubscription: NONE");
        } else {
            System.out.println("\tSubscription: " + currentSubscription.getPlan().getName()
                    + " | " + currentSubscription.getStatus(today)
                    + " | " + currentSubscription.getStartDate()
                    + " to " + currentSubscription.getEndDate());
        }
        System.out.print("\tAttendance: " + attendance.size() + " visit(s)");
        if (!attendance.isEmpty()) {
            StringBuilder dates = new StringBuilder();
            for (AttendanceRecord r : attendance) {
                if (dates.length() > 0) {
                    dates.append(", ");
                }
                dates.append(r.getDate());
            }
            System.out.print(" -> " + dates);
        }
        System.out.println();
    }
}
