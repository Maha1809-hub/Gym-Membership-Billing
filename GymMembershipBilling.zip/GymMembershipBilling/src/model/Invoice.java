package model;

public class Invoice {

    public static final double TAX_RATE = 0.18;

    private final int invoiceId;
    private final Subscription subscription;
    private final double subtotal;
    private final double penalty;
    private final double tax;
    private final double total;
    private boolean paid;

    public Invoice(int invoiceId, Subscription subscription) {
        this.invoiceId = invoiceId;
        this.subscription = subscription;
        this.subtotal = subscription.getPlan().getPrice();
        this.penalty = subscription.getPenalty();
        this.tax = (subtotal + penalty) * TAX_RATE;
        this.total = subtotal + penalty + tax;
    }

    public int getInvoiceId() {
        return invoiceId;
    }

    public Subscription getSubscription() {
        return subscription;
    }

    public double getTotal() {
        return total;
    }

    public boolean isPaid() {
        return paid;
    }

    public void markPaid() {
        this.paid = true;
    }

    public void displayInvoice() {
        Plan plan = subscription.getPlan();
        System.out.println("\n============ INVOICE ============");
        System.out.println("Invoice ID : " + invoiceId);
        System.out.println("Member     : " + subscription.getMember().getName()
                + " (ID: " + subscription.getMember().getId() + ")");
        System.out.println("Plan       : " + plan.getName() + " [" + plan.getType() + "]");
        System.out.println("Cycle      : " + plan.getCycle());
        System.out.printf("Subtotal   : Rs. %.2f%n", subtotal);
        System.out.printf("Penalty    : Rs. %.2f%n", penalty);
        System.out.printf("Tax (18%%)  : Rs. %.2f%n", tax);
        System.out.printf("TOTAL      : Rs. %.2f%n", total);
        System.out.println("Status     : " + (paid ? "PAID" : "UNPAID"));
        System.out.println("=================================");
    }
}
