package service;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

import exception.GymException;
import model.AttendanceRecord;
import model.BillingCycle;
import model.Invoice;
import model.Member;
import model.Payment;
import model.Plan;
import model.PremiumPlan;
import model.Subscription;
import model.Trainer;

public class GymService {

    private final List<Member> members = new ArrayList<>();
    private final List<Plan> plans = new ArrayList<>();
    private final List<Trainer> trainers = new ArrayList<>();
    private final List<Invoice> invoices = new ArrayList<>();
    private final List<Payment> payments = new ArrayList<>();
    private int nextSubscriptionId = 5001;
    private int nextInvoiceId = 9001;
    private int nextPaymentId = 7001;

    public GymService() {
        trainers.add(new Trainer(1, "Ravi", "Cardio"));
        trainers.add(new Trainer(2, "Priya", "Strength"));
        trainers.add(new Trainer(3, "Karthik", "Yoga"));
    }

    public static LocalDate today() {
        String fixed = System.getProperty("gym.today");
        return fixed == null ? LocalDate.now() : LocalDate.parse(fixed);
    }

    public void displayTrainers() {
        for (Trainer t : trainers) {
            System.out.println("\t" + t);
        }
    }

    public void displayPlans() {
        if (plans.isEmpty()) {
            System.out.println("\t(no plans added yet)");
        }
        for (Plan p : plans) {
            System.out.println("\t" + p);
        }
    }

    public void addPlan(int id, String name, boolean premium, BillingCycle cycle,
                        double price, int graceDays, double penaltyPerDay) {
        if (findPlan(id) != null) {
            throw new GymException("A plan with this ID already exists.");
        }
        Plan plan = premium
                ? new PremiumPlan(id, name, cycle, price, graceDays, penaltyPerDay)
                : new Plan(id, name, cycle, price, graceDays, penaltyPerDay);
        plans.add(plan);
        System.out.println("Plan added successfully.");
        System.out.println(plan);
    }

    public void addMember(int id, String name, String phone, int trainerId) {
        if (findMember(id) != null) {
            throw new GymException("A member with this ID already exists.");
        }
        Trainer trainer = findTrainer(trainerId);
        if (trainer == null) {
            throw new GymException("Trainer ID not found.");
        }
        Member member = new Member(id, name, phone, trainer);
        members.add(member);
        System.out.println("Member added successfully.");
        member.displayMember(today());
    }

    public void startOrRenew(int memberId, int planId, LocalDate startDate) {
        Member member = requireMember(memberId);
        Plan plan = findPlan(planId);
        if (plan == null) {
            throw new GymException("Plan ID not found.");
        }
        Subscription previous = member.getCurrentSubscription();
        long daysLate = 0;
        if (previous != null) {
            daysLate = Math.max(0, ChronoUnit.DAYS.between(previous.getEndDate(), startDate));
        }
        double penalty = previous == null ? 0.0 : plan.calculatePenalty(daysLate);
        Subscription sub = new Subscription(nextSubscriptionId++, member, plan, startDate, penalty);
        member.setCurrentSubscription(sub);

        System.out.println("\n---- " + (previous == null ? "SUBSCRIPTION STARTED"
                : "SUBSCRIPTION RENEWED") + " ----");
        System.out.println("Subscription ID: " + sub.getSubscriptionId());
        if (previous != null) {
            System.out.println("Previous expiry: " + previous.getEndDate()
                    + " | Days late: " + daysLate);
            System.out.printf("Late renewal penalty: Rs. %.2f%n", penalty);
        }
        sub.displayStatus(today());
    }

    public void recordAttendance(int memberId, LocalDate date) {
        Member member = requireMember(memberId);
        Subscription sub = member.getCurrentSubscription();
        if (sub == null || !sub.isActiveOn(date)) {
            throw new GymException("Attendance denied: " + member.getName()
                    + " has no active subscription on " + date + ".");
        }
        for (AttendanceRecord r : member.getAttendance()) {
            if (r.getDate().equals(date)) {
                throw new GymException("Attendance already recorded for " + date + ".");
            }
        }
        member.addAttendance(new AttendanceRecord(member, date));
        System.out.println("\n---- ATTENDANCE RECORDED ----");
        System.out.println("Member: " + member.getName() + " | Date: " + date
                + " | Total visits: " + member.getAttendance().size());
        sub.displayStatus(today());
    }

    public void generateInvoice(int memberId) {
        Member member = requireMember(memberId);
        Subscription sub = member.getCurrentSubscription();
        if (sub == null) {
            throw new GymException("Member has no subscription to invoice.");
        }
        if (sub.isInvoiced()) {
            throw new GymException("An invoice has already been generated for this subscription.");
        }
        Invoice invoice = new Invoice(nextInvoiceId++, sub);
        sub.setInvoiced(true);
        invoices.add(invoice);
        invoice.displayInvoice();
    }

    public void recordPayment(int invoiceId, double amount, String method) {
        Invoice invoice = findInvoice(invoiceId);
        if (invoice == null) {
            throw new GymException("Payment rejected: invoice not found. Generate an invoice first.");
        }
        if (invoice.isPaid()) {
            throw new GymException("This invoice is already paid.");
        }
        if (Math.abs(amount - invoice.getTotal()) > 0.01) {
            throw new GymException(String.format(
                    "Amount mismatch. Invoice total is Rs. %.2f.", invoice.getTotal()));
        }
        invoice.markPaid();
        Payment payment = new Payment(nextPaymentId++, invoice, amount, method, today());
        payments.add(payment);
        payment.displayReceipt();
        invoice.getSubscription().displayStatus(today());
    }

    public void displayMembers() {
        System.out.println("\n========== MEMBERS ==========");
        if (members.isEmpty()) {
            System.out.println("No members registered.");
        }
        for (Member m : members) {
            m.displayMember(today());
        }
        System.out.println("=============================");
    }

    private Member requireMember(int id) {
        Member member = findMember(id);
        if (member == null) {
            throw new GymException("Member ID not found.");
        }
        return member;
    }

    private Member findMember(int id) {
        for (Member m : members) {
            if (m.getId() == id) {
                return m;
            }
        }
        return null;
    }

    private Plan findPlan(int id) {
        for (Plan p : plans) {
            if (p.getPlanId() == id) {
                return p;
            }
        }
        return null;
    }

    private Trainer findTrainer(int id) {
        for (Trainer t : trainers) {
            if (t.getId() == id) {
                return t;
            }
        }
        return null;
    }

    private Invoice findInvoice(int id) {
        for (Invoice i : invoices) {
            if (i.getInvoiceId() == id) {
                return i;
            }
        }
        return null;
    }
}
