# Gym Membership & Billing System

**Course:** 23CSR306 Java Programming
**Assignment:** II – OOP Mini Project, Specification 17: Gym Membership & Billing
**Name:** MAHALAKSHMI S
**Register Number:** 717825P325
**Year / Dept / Sem / Section:** II / CSE / III / C

## Problem Statement
A Java console application that manages gym memberships, plans, attendance,
payments and renewals while keeping membership status and dues accurate.

## Business Rules
1. A member must have an active subscription to record attendance.
2. Subscription activation/renewal updates validity dates immediately.
3. An invoice must be generated before a payment is accepted.
4. Late renewals may include a penalty fee as per plan policy
   (Premium plans cap the penalty at Rs. 300).
5. Attendance records are linked to the member and the date.

## OOP Concepts Used
- **Encapsulation:** private fields with getters in every model class.
- **Inheritance:** `Member` and `Trainer` extend abstract `Person`; `PremiumPlan` extends `Plan`.
- **Aggregation:** `Member` has a `Subscription`, `Trainer` and `AttendanceRecord` list; `Invoice` has a `Subscription`.
- **Polymorphism:** `getRole()`, `getType()`, `calculatePenalty()` and `policyText()` are overridden.

## Project Structure
```
src/
  main/Main.java
  model/        Person, Trainer, Member, Plan, PremiumPlan, BillingCycle,
                Subscription, AttendanceRecord, Invoice, Payment
  service/GymService.java
  exception/GymException.java
```

## How to Run
```
cd GymMembershipBilling
mkdir -p out
javac -d out $(find src -name "*.java")
java -cp out main.Main
```
Optional: fix the "today" date for testing with `java -Dgym.today=2026-10-26 -cp out main.Main`.

## Menu
1. Add Member
2. Add Plan
3. Start or Renew Subscription
4. Record Attendance
5. Generate Invoice
6. Record Payment
7. Display Members
8. Exit
